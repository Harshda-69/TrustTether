import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useWallet } from "@/hooks/useWallet";
import { uploadToIPFS } from "@/lib/ipfs";
import { commentPost } from "@/lib/web3";
import { MessageCircle, Send, Info } from "lucide-react";
import type { Post } from "@shared/schema";

type PostWithReputation = Post & { authorReputation?: number };

interface CommentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  post: PostWithReputation;
}

export default function CommentModal({ open, onOpenChange, post }: CommentModalProps) {
  const [comment, setComment] = useState("");
  const { toast } = useToast();
  const { isConnected, address } = useWallet();
  const queryClient = useQueryClient();

  const commentMutation = useMutation({
    mutationFn: async (commentText: string) => {
      if (!isConnected || !address) {
        throw new Error("Wallet not connected");
      }

      // Upload comment to IPFS
      const commentData = {
        text: commentText,
        timestamp: Date.now(),
        author: address,
        postId: post.id
      };
      
      const commentHash = await uploadToIPFS(JSON.stringify(commentData));

      // Call smart contract
      const txHash = await commentPost(post.id, commentHash);
      
      // Store in backend
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postId: post.id,
          author: address,
          content: commentText,
          ipfsHash: commentHash,
          transactionHash: txHash
        })
      });

      if (!response.ok) {
        throw new Error('Failed to store comment');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Comment Added!",
        description: "Your comment has been recorded on-chain.",
        variant: "default",
      });
      setComment("");
      onOpenChange(false);
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add comment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const truncateAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const getAuthorInitial = (address: string) => {
    return address.charAt(2).toUpperCase();
  };

  const handleSubmit = () => {
    if (!comment.trim()) {
      toast({
        title: "Comment required",
        description: "Please enter a comment",
        variant: "destructive",
      });
      return;
    }

    commentMutation.mutate(comment);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card modal-content rounded-2xl max-w-2xl w-full p-6 border border-border">
        {/* Modal Header */}
        <DialogHeader className="mb-6">
          <DialogTitle className="text-2xl font-bold flex items-center">
            <MessageCircle className="text-primary mr-2" />
            Add Comment
          </DialogTitle>
        </DialogHeader>
        
        {/* Original Post Preview */}
        <div className="bg-muted/30 rounded-lg p-4 mb-6 border border-border/30">
          <div className="flex items-center space-x-2 mb-2">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground font-bold text-sm">
                {getAuthorInitial(post.author)}
              </AvatarFallback>
            </Avatar>
            <span className="text-sm font-medium truncate-address">{truncateAddress(post.author)}</span>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-3">{post.content}</p>
        </div>
        
        {/* Comment Input */}
        <div className="space-y-4">
          <Textarea 
            className="w-full bg-input border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all resize-none"
            rows={4}
            placeholder="Share your thoughts..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            disabled={commentMutation.isPending}
            data-testid="textarea-comment"
          />
          
          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3">
            <Button 
              variant="ghost"
              className="px-6 py-2.5 rounded-lg text-foreground hover:bg-muted transition-colors"
              onClick={() => onOpenChange(false)}
              disabled={commentMutation.isPending}
              data-testid="button-cancel-comment"
            >
              Cancel
            </Button>
            <Button 
              className="btn-primary text-primary-foreground px-6 py-2.5 rounded-lg font-semibold flex items-center space-x-2"
              onClick={handleSubmit}
              disabled={commentMutation.isPending || !comment.trim()}
              data-testid="button-submit-comment"
            >
              {commentMutation.isPending ? (
                <div className="loading-spinner w-4 h-4 rounded-full mr-2"></div>
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>{commentMutation.isPending ? "Posting..." : "Post Comment"}</span>
            </Button>
          </div>
          
          <p className="text-xs text-muted-foreground text-center flex items-center justify-center">
            <Info className="w-3 h-3 mr-1" />
            Comment will be stored on IPFS and linked on-chain
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
