import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useWallet } from "@/hooks/useWallet";
import { uploadToIPFS } from "@/lib/ipfs";
import { createPost } from "@/lib/web3";
import { CloudUpload, Rocket, Info, X } from "lucide-react";

export default function CreatePost() {
  const [content, setContent] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const { toast } = useToast();
  const { isConnected, address } = useWallet();
  const queryClient = useQueryClient();

  const createPostMutation = useMutation({
    mutationFn: async ({ content, imageFile }: { content: string; imageFile?: File }) => {
      if (!isConnected || !address) {
        throw new Error("Wallet not connected");
      }

      // Upload content to IPFS
      const contentData = {
        text: content,
        timestamp: Date.now(),
        author: address
      };
      
      const contentHash = await uploadToIPFS(JSON.stringify(contentData));
      
      let imageHash = null;
      if (imageFile) {
        imageHash = await uploadToIPFS(imageFile);
      }

      // Call smart contract
      const txHash = await createPost(contentHash);
      
      // Store in backend
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          author: address,
          content,
          ipfsHash: contentHash,
          imageHash,
          blockNumber: 0, // Will be updated when tx confirms
          transactionHash: txHash
        })
      });

      if (!response.ok) {
        throw new Error('Failed to store post');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Post Created!",
        description: "Your post has been published on-chain.",
        variant: "default",
      });
      setContent("");
      setSelectedFile(null);
      setPreviewUrl("");
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select a file smaller than 5MB",
          variant: "destructive",
        });
        return;
      }

      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedFile(null);
    setPreviewUrl("");
  };

  const handleSubmit = () => {
    if (!content.trim()) {
      toast({
        title: "Content required",
        description: "Please enter some content for your post",
        variant: "destructive",
      });
      return;
    }

    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to create a post",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate({ content, imageFile: selectedFile || undefined });
  };

  return (
    <div className="glass-card rounded-xl p-6 border border-border/50 sticky top-24">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <i className="fas fa-plus-circle text-primary mr-2"></i>
        Create Post
      </h2>
      
      <div className="space-y-4">
        <div>
          <Textarea 
            className="w-full bg-input border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all resize-none"
            rows={4}
            placeholder="Share your thoughts on-chain..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            disabled={createPostMutation.isPending}
            data-testid="textarea-post-content"
          />
        </div>
        
        {/* Image Upload */}
        <div>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
            id="image-upload"
            data-testid="input-image-upload"
          />
          <label 
            htmlFor="image-upload"
            className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer flex flex-col items-center"
          >
            <CloudUpload className="w-8 h-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">Click to upload image</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Max 5MB • PNG, JPG, GIF</p>
          </label>
        </div>
        
        {/* Preview */}
        {previewUrl && (
          <div className="rounded-lg overflow-hidden border border-border">
            <img src={previewUrl} alt="Upload preview" className="w-full h-48 object-cover" />
            <div className="bg-input p-2 flex justify-between items-center">
              <span className="text-xs text-muted-foreground truncate-address">Preview</span>
              <Button
                variant="ghost"
                size="icon"
                className="text-destructive hover:text-destructive/80 h-6 w-6"
                onClick={removeImage}
                data-testid="button-remove-image"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
        
        {/* Create Button */}
        <Button 
          className="w-full btn-primary text-primary-foreground font-semibold py-3 rounded-lg flex items-center justify-center space-x-2"
          onClick={handleSubmit}
          disabled={createPostMutation.isPending || !isConnected}
          data-testid="button-create-post"
        >
          {createPostMutation.isPending ? (
            <div className="loading-spinner w-4 h-4 rounded-full mr-2"></div>
          ) : (
            <Rocket className="w-4 h-4" />
          )}
          <span>{createPostMutation.isPending ? "Posting..." : "Post On-Chain"}</span>
        </Button>
        
        <p className="text-xs text-muted-foreground text-center flex items-center justify-center">
          <Info className="w-3 h-3 mr-1" />
          Your post will be stored on IPFS
        </p>
      </div>
    </div>
  );
}
