import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { User } from "@shared/schema";
import { uploadToIPFS } from "@/lib/ipfs";
import { Loader2, Upload, X } from "lucide-react";

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
}

export default function EditProfileModal({ isOpen, onClose, currentUser }: EditProfileModalProps) {
  const { toast } = useToast();
  const [name, setName] = useState(currentUser.name || "");
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl || "");
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  // Sync local state when currentUser changes
  useEffect(() => {
    setName(currentUser.name || "");
    setAvatarUrl(currentUser.avatarUrl || "");
  }, [currentUser.name, currentUser.avatarUrl]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: { name?: string; avatarUrl?: string }) => {
      return apiRequest("PATCH", `/api/users/${currentUser.address}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", currentUser.address] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    setIsUploadingAvatar(true);
    try {
      const hash = await uploadToIPFS(file);
      const url = `https://${hash}.ipfs.w3s.link`;
      setAvatarUrl(url);
      toast({
        title: "Avatar Uploaded",
        description: "Your avatar has been uploaded to IPFS.",
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "Failed to upload avatar to IPFS.",
        variant: "destructive",
      });
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() && !avatarUrl) {
      toast({
        title: "No Changes",
        description: "Please make at least one change to your profile.",
        variant: "destructive",
      });
      return;
    }

    updateProfileMutation.mutate({
      name: name.trim() || undefined,
      avatarUrl: avatarUrl || undefined,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
        <DialogHeader>
          <DialogTitle className="text-white">Edit Profile</DialogTitle>
          <DialogDescription className="text-zinc-400">
            Update your name and avatar. Changes are stored on-chain.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col items-center gap-4">
            <Avatar className="h-24 w-24 border-2 border-green-500">
              <AvatarImage src={avatarUrl || undefined} />
              <AvatarFallback className="bg-zinc-800 text-2xl">
                {name?.[0]?.toUpperCase() || currentUser.address.slice(0, 2)}
              </AvatarFallback>
            </Avatar>

            <div className="flex gap-2">
              <Label htmlFor="avatar-upload">
                <Button
                  type="button"
                  variant="outline"
                  className="border-green-500 text-green-400 hover:bg-green-500/10 cursor-pointer"
                  disabled={isUploadingAvatar}
                  asChild
                  data-testid="button-upload-avatar"
                >
                  <span>
                    {isUploadingAvatar ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="mr-2 h-4 w-4" />
                    )}
                    Upload Avatar
                  </span>
                </Button>
              </Label>
              <Input
                id="avatar-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleAvatarUpload}
                disabled={isUploadingAvatar}
              />
              {avatarUrl && (
                <Button
                  type="button"
                  variant="outline"
                  className="border-red-500 text-red-400 hover:bg-red-500/10"
                  onClick={() => setAvatarUrl("")}
                  data-testid="button-remove-avatar"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name" className="text-white">
              Display Name
            </Label>
            <Input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              maxLength={50}
              className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500"
              data-testid="input-profile-name"
            />
            <p className="text-xs text-zinc-500">
              {name.length}/50 characters
            </p>
          </div>

          <div className="flex gap-3 justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={updateProfileMutation.isPending}
              className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
              data-testid="button-cancel-edit"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={updateProfileMutation.isPending || isUploadingAvatar}
              className="bg-green-500 hover:bg-green-600 text-black"
              data-testid="button-save-profile"
            >
              {updateProfileMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
