import { Link2, Wallet, LogOut, User } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { Button } from "@/components/ui/button";

export default function Header() {
  const { isConnected, address, balance, connect, disconnect, isConnecting } = useWallet();

  const truncateAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  return (
    <header className="sticky top-0 z-50 glass-card border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <Link2 className="text-primary-foreground text-xl" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">TrustTether</h1>
              <p className="text-xs text-muted-foreground">On-Chain Social</p>
            </div>
          </div>
          
          {/* Navigation & Wallet */}
          <div className="flex items-center space-x-4">
            {/* Network Status */}
            <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-secondary/20 border border-secondary/30">
              <div className="w-2 h-2 rounded-full bg-primary pulse-glow"></div>
              <span className="text-sm text-muted-foreground">HeLa Testnet</span>
            </div>
            
            {/* Wallet Connection */}
            {!isConnected ? (
              <Button 
                className="btn-primary connect-button text-primary-foreground font-semibold px-6 py-2.5 rounded-lg flex items-center space-x-2 relative z-10"
                onClick={connect}
                disabled={isConnecting}
                data-testid="button-connect-wallet"
              >
                <Wallet className="w-4 h-4" />
                <span>{isConnecting ? "Connecting..." : "Connect Wallet"}</span>
              </Button>
            ) : (
              <div className="flex items-center space-x-3 px-4 py-2 rounded-lg glass-card" data-testid="wallet-info">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                    <User className="text-primary-foreground text-xs" />
                  </div>
                  <div>
                    <p className="text-sm font-medium truncate-address" data-testid="wallet-address">
                      {truncateAddress(address)}
                    </p>
                    <p className="text-xs text-muted-foreground" data-testid="wallet-balance">
                      {balance} HELA
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive hover:text-destructive/80 transition-colors"
                  onClick={disconnect}
                  data-testid="button-disconnect-wallet"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
