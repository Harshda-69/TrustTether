import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Gift, Flame, Clock, RefreshCw } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { formatDistanceToNow } from "date-fns";
import CommentModal from "./CommentModal";
import TipModal from "./TipModal";
import { likePost } from "@/lib/web3";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { Post } from "@shared/schema";

type PostWithReputation = Post & { 
  authorReputation?: number;
  authorName?: string | null;
  authorAvatar?: string | null;
};

export default function PostFeed() {
  const [selectedPost, setSelectedPost] = useState<PostWithReputation | null>(null);
  const [showCommentModal, setShowCommentModal] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const { isConnected, address } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: posts, isLoading, refetch } = useQuery<PostWithReputation[]>({
    queryKey: ['/api/posts'],
    enabled: true,
  });

  const likeMutation = useMutation({
    mutationFn: async (postId: string) => {
      if (!isConnected || !address) {
        throw new Error("Wallet not connected");
      }

      const txHash = await likePost(postId);
      
      const response = await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postId,
          author: address,
          transactionHash: txHash
        })
      });

      if (!response.ok) {
        throw new Error('Failed to store like');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Post Liked!",
        description: "Your like has been recorded on-chain.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to like post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const truncateAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const getAuthorInitial = (address: string) => {
    return address.charAt(2).toUpperCase();
  };

  const handleLike = (post: PostWithReputation) => {
    likeMutation.mutate(post.id);
  };

  const handleComment = (post: PostWithReputation) => {
    setSelectedPost(post);
    setShowCommentModal(true);
  };

  const handleTip = (post: PostWithReputation) => {
    setSelectedPost(post);
    setShowTipModal(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold flex items-center">
            <i className="fas fa-stream text-primary mr-2"></i>
            Social Feed
          </h2>
        </div>
        
        {/* Loading skeletons */}
        {[...Array(3)].map((_, i) => (
          <div key={i} className="glass-card rounded-xl p-6 border border-border/50 animate-pulse">
            <div className="flex items-start space-x-3 mb-4">
              <div className="w-12 h-12 bg-muted rounded-full"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-muted rounded w-1/4"></div>
                <div className="h-3 bg-muted rounded w-1/6"></div>
              </div>
            </div>
            <div className="space-y-2 mb-4">
              <div className="h-4 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded w-3/4"></div>
            </div>
            <div className="h-48 bg-muted rounded-lg mb-4"></div>
            <div className="flex items-center justify-between">
              <div className="flex space-x-4">
                <div className="h-8 bg-muted rounded w-20"></div>
                <div className="h-8 bg-muted rounded w-24"></div>
                <div className="h-8 bg-muted rounded w-16"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        {/* Feed Header */}
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold flex items-center">
            <i className="fas fa-stream text-primary mr-2"></i>
            Social Feed
          </h2>
          <div className="flex items-center space-x-2">
            <Button className="btn-secondary text-foreground px-4 py-2 rounded-lg text-sm" data-testid="button-trending">
              <Flame className="w-4 h-4 mr-2" />
              Trending
            </Button>
            <Button 
              variant="ghost"
              className="text-muted-foreground hover:text-foreground px-4 py-2 rounded-lg text-sm transition-colors"
              data-testid="button-recent"
            >
              <Clock className="w-4 h-4 mr-2" />
              Recent
            </Button>
          </div>
        </div>
        
        {/* Posts */}
        {posts?.map((post: PostWithReputation) => (
          <article key={post.id} className="glass-card rounded-xl p-6 border border-border/50 hover:border-border transition-all">
            {/* Post Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Link href={`/profile/${post.author}`} data-testid={`link-profile-${post.id}`}>
                  <Avatar className="w-12 h-12 cursor-pointer hover:opacity-80 transition-opacity">
                    {post.authorAvatar && <AvatarImage src={post.authorAvatar} />}
                    <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground font-bold text-lg">
                      {post.authorName?.[0]?.toUpperCase() || getAuthorInitial(post.author)}
                    </AvatarFallback>
                  </Avatar>
                </Link>
                <div>
                  <div className="flex items-center space-x-2">
                    <Link href={`/profile/${post.author}`} data-testid={`link-author-${post.id}`}>
                      <p className="font-semibold text-foreground truncate-address hover:text-green-400 transition-colors cursor-pointer">
                        {post.authorName || truncateAddress(post.author)}
                      </p>
                    </Link>
                    <Badge className="reputation-badge text-xs px-2 py-0.5 rounded-full text-primary-foreground font-medium">
                      <i className="fas fa-star text-xs mr-1"></i>
                      {post.authorReputation || 0}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(post.createdAt!), { addSuffix: true })} • Block #{post.blockNumber || "Pending"}
                  </p>
                </div>
              </div>
              
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground transition-colors">
                <i className="fas fa-ellipsis-h"></i>
              </Button>
            </div>
            
            {/* Post Content */}
            <div className="mb-4">
              <p className="text-foreground mb-3 leading-relaxed" data-testid={`post-content-${post.id}`}>
                {post.content}
              </p>
              
              {/* Post Image */}
              {post.imageHash && (
                <img 
                  src={`https://ipfs.io/ipfs/${post.imageHash}`}
                  alt="Post content"
                  className="w-full rounded-lg post-image border border-border/30"
                  data-testid={`post-image-${post.id}`}
                />
              )}
            </div>
            
            {/* Post Metadata */}
            <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4 pb-4 border-b border-border/30">
              <span><i className="fas fa-database mr-1"></i>IPFS: {post.ipfsHash.slice(0, 8)}...{post.ipfsHash.slice(-4)}</span>
              <span><i className="fas fa-cube mr-1"></i>TX: {post.transactionHash.slice(0, 6)}...{post.transactionHash.slice(-4)}</span>
            </div>
            
            {/* Engagement Stats */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4 text-sm">
                <span className="text-muted-foreground" data-testid={`post-likes-${post.id}`}>
                  <Heart className="w-4 h-4 text-accent mr-1 inline" />
                  {post.likesCount || 0} likes
                </span>
                <span className="text-muted-foreground" data-testid={`post-comments-${post.id}`}>
                  <MessageCircle className="w-4 h-4 mr-1 inline" />
                  {post.commentsCount || 0} comments
                </span>
                <span className="text-muted-foreground" data-testid={`post-tips-${post.id}`}>
                  <Gift className="w-4 h-4 text-primary mr-1 inline" />
                  {parseFloat(post.tipsReceived || "0").toFixed(1)} HELA
                </span>
              </div>
            </div>
            
            {/* Engagement Buttons */}
            <div className="grid grid-cols-3 gap-3">
              <Button 
                className="engagement-button btn-secondary text-foreground px-4 py-2.5 rounded-lg flex items-center justify-center space-x-2 hover:bg-accent/20 hover:text-accent"
                onClick={() => handleLike(post)}
                disabled={likeMutation.isPending || !isConnected}
                data-testid={`button-like-${post.id}`}
              >
                <Heart className="w-4 h-4" />
                <span className="font-medium">Like</span>
              </Button>
              
              <Button 
                className="engagement-button btn-secondary text-foreground px-4 py-2.5 rounded-lg flex items-center justify-center space-x-2 hover:bg-primary/20 hover:text-primary"
                onClick={() => handleComment(post)}
                disabled={!isConnected}
                data-testid={`button-comment-${post.id}`}
              >
                <MessageCircle className="w-4 h-4" />
                <span className="font-medium">Comment</span>
              </Button>
              
              <Button 
                className="engagement-button btn-secondary text-foreground px-4 py-2.5 rounded-lg flex items-center justify-center space-x-2 hover:bg-primary/20 hover:text-primary"
                onClick={() => handleTip(post)}
                disabled={!isConnected}
                data-testid={`button-tip-${post.id}`}
              >
                <Gift className="w-4 h-4" />
                <span className="font-medium">Tip</span>
              </Button>
            </div>
          </article>
        ))}
        
        {/* Load More */}
        <div className="text-center py-8">
          <Button 
            className="btn-secondary text-foreground px-8 py-3 rounded-lg font-medium hover:bg-primary/20 hover:text-primary transition-all"
            onClick={() => refetch()}
            data-testid="button-load-more"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Load More Posts
          </Button>
        </div>
      </div>

      {/* Modals */}
      {selectedPost && (
        <>
          <CommentModal
            open={showCommentModal}
            onOpenChange={setShowCommentModal}
            post={selectedPost}
          />
          <TipModal
            open={showTipModal}
            onOpenChange={setShowTipModal}
            post={selectedPost}
          />
        </>
      )}
    </>
  );
}
