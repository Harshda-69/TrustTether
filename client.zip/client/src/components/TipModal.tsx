import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useWallet } from "@/hooks/useWallet";
import { tipAuthor } from "@/lib/web3";
import { Gift, Send, Shield } from "lucide-react";
import type { Post } from "@shared/schema";

type PostWithReputation = Post & { authorReputation?: number };

interface TipModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  post: PostWithReputation;
}

export default function TipModal({ open, onOpenChange, post }: TipModalProps) {
  const [amount, setAmount] = useState("");
  const { toast } = useToast();
  const { isConnected, address, balance } = useWallet();
  const queryClient = useQueryClient();

  const tipMutation = useMutation({
    mutationFn: async (tipAmount: string) => {
      if (!isConnected || !address) {
        throw new Error("Wallet not connected");
      }

      const amountFloat = parseFloat(tipAmount);
      if (isNaN(amountFloat) || amountFloat <= 0) {
        throw new Error("Invalid amount");
      }

      if (amountFloat > parseFloat(balance)) {
        throw new Error("Insufficient balance");
      }

      // Call smart contract to send tip
      const txHash = await tipAuthor(post.id, tipAmount);
      
      // Store in backend
      const response = await fetch('/api/tips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postId: post.id,
          fromAddress: address,
          toAddress: post.author,
          amount: tipAmount,
          transactionHash: txHash
        })
      });

      if (!response.ok) {
        throw new Error('Failed to store tip');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Tip Sent!",
        description: "Your tip has been sent on-chain.",
        variant: "default",
      });
      setAmount("");
      onOpenChange(false);
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send tip",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const truncateAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const getAuthorInitial = (address: string) => {
    return address.charAt(2).toUpperCase();
  };

  const handleQuickAmount = (value: string) => {
    setAmount(value);
  };

  const handleSubmit = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid tip amount",
        variant: "destructive",
      });
      return;
    }

    tipMutation.mutate(amount);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card modal-content rounded-2xl max-w-md w-full p-6 border border-border">
        {/* Modal Header */}
        <DialogHeader className="mb-6">
          <DialogTitle className="text-2xl font-bold flex items-center">
            <Gift className="text-primary mr-2" />
            Send Tip
          </DialogTitle>
        </DialogHeader>
        
        {/* Recipient Info */}
        <div className="bg-muted/30 rounded-lg p-4 mb-6 border border-border/30">
          <p className="text-sm text-muted-foreground mb-2">Sending tip to:</p>
          <div className="flex items-center space-x-2">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground font-bold">
                {getAuthorInitial(post.author)}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium truncate-address">{truncateAddress(post.author)}</p>
              <p className="text-xs text-muted-foreground">Reputation: {post.authorReputation || 0}</p>
            </div>
          </div>
        </div>
        
        {/* Tip Amount */}
        <div className="space-y-4">
          <div>
            <Label className="block text-sm font-medium mb-2">Amount (HELA)</Label>
            <Input 
              type="number" 
              className="w-full bg-input border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all"
              placeholder="0.00"
              step="0.1"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              disabled={tipMutation.isPending}
              data-testid="input-tip-amount"
            />
          </div>
          
          {/* Quick Amount Buttons */}
          <div className="grid grid-cols-4 gap-2">
            {["1", "5", "10", "25"].map((value) => (
              <Button 
                key={value}
                variant="outline"
                className="btn-secondary text-foreground px-3 py-2 rounded-lg text-sm font-medium hover:bg-primary/20 hover:text-primary"
                onClick={() => handleQuickAmount(value)}
                disabled={tipMutation.isPending}
                data-testid={`button-quick-amount-${value}`}
              >
                {value}
              </Button>
            ))}
          </div>
          
          {/* Your Balance */}
          <div className="bg-primary/10 rounded-lg p-3 border border-primary/20">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Your Balance</span>
              <span className="font-semibold text-foreground" data-testid="balance-display">
                {balance} HELA
              </span>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex items-center space-x-3 pt-2">
            <Button 
              variant="ghost"
              className="flex-1 px-6 py-2.5 rounded-lg text-foreground hover:bg-muted transition-colors"
              onClick={() => onOpenChange(false)}
              disabled={tipMutation.isPending}
              data-testid="button-cancel-tip"
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 btn-primary text-primary-foreground px-6 py-2.5 rounded-lg font-semibold flex items-center justify-center space-x-2"
              onClick={handleSubmit}
              disabled={tipMutation.isPending || !amount || parseFloat(amount) <= 0}
              data-testid="button-send-tip"
            >
              {tipMutation.isPending ? (
                <div className="loading-spinner w-4 h-4 rounded-full mr-2"></div>
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>{tipMutation.isPending ? "Sending..." : "Send Tip"}</span>
            </Button>
          </div>
          
          <p className="text-xs text-muted-foreground text-center flex items-center justify-center">
            <Shield className="w-3 h-3 mr-1" />
            Transaction will be verified on HeLa blockchain
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
