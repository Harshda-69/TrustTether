import { Web3Storage } from 'web3.storage';

const WEB3_STORAGE_TOKEN = import.meta.env.VITE_WEB3_STORAGE_TOKEN;

function getClient() {
  if (!WEB3_STORAGE_TOKEN) {
    throw new Error('VITE_WEB3_STORAGE_TOKEN environment variable is required for IPFS uploads');
  }
  return new Web3Storage({ token: WEB3_STORAGE_TOKEN });
}

export async function uploadToIPFS(data: string | File): Promise<string> {
  try {
    const client = getClient();
    let file: File;

    if (typeof data === 'string') {
      // Convert string to file
      const blob = new Blob([data], { type: 'application/json' });
      file = new File([blob], `data-${Date.now()}.json`, { type: 'application/json' });
    } else {
      // Already a file
      file = data;
    }

    const cid = await client.put([file]);
    return cid;
  } catch (error: any) {
    console.error('IPFS upload error:', error);
    throw new Error(`Failed to upload to IPFS: ${error.message}`);
  }
}

export async function getFromIPFS(cid: string): Promise<string> {
  try {
    const client = getClient();
    const res = await client.get(cid);
    
    if (!res?.ok) {
      throw new Error('Failed to fetch from IPFS');
    }

    const files = await res.files();
    const file = files[0];
    
    if (!file) {
      throw new Error('No file found');
    }

    return await file.text();
  } catch (error: any) {
    console.error('IPFS fetch error:', error);
    throw new Error(`Failed to fetch from IPFS: ${error.message}`);
  }
}
