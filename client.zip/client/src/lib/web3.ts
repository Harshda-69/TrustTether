import { ethers } from 'ethers';
import { CONTRACT_ADDRESS, CONTRACT_ABI } from '../config';

export async function createPost(ipfsHash: string): Promise<string> {
  if (!window.ethereum) {
    throw new Error('MetaMask not found');
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

  try {
    const tx = await contract.createPost(ipfsHash);
    return tx.hash;
  } catch (error: any) {
    throw new Error(error.message || 'Failed to create post');
  }
}

export async function likePost(postId: string): Promise<string> {
  if (!window.ethereum) {
    throw new Error('MetaMask not found');
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

  try {
    const tx = await contract.likePost(postId);
    return tx.hash;
  } catch (error: any) {
    throw new Error(error.message || 'Failed to like post');
  }
}

export async function commentPost(postId: string, ipfsHash: string): Promise<string> {
  if (!window.ethereum) {
    throw new Error('MetaMask not found');
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

  try {
    const tx = await contract.commentPost(postId, ipfsHash);
    return tx.hash;
  } catch (error: any) {
    throw new Error(error.message || 'Failed to add comment');
  }
}

export async function tipAuthor(postId: string, amount: string): Promise<string> {
  if (!window.ethereum) {
    throw new Error('MetaMask not found');
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

  try {
    const value = ethers.parseEther(amount);
    const tx = await contract.tipAuthor(postId, { value });
    return tx.hash;
  } catch (error: any) {
    throw new Error(error.message || 'Failed to send tip');
  }
}

export async function getPosts(): Promise<any[]> {
  if (!window.ethereum) {
    throw new Error('MetaMask not found');
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

  try {
    const posts = await contract.getPosts();
    return posts;
  } catch (error: any) {
    throw new Error(error.message || 'Failed to fetch posts');
  }
}

export async function getUserReputation(address: string): Promise<number> {
  if (!window.ethereum) {
    throw new Error('MetaMask not found');
  }

  const provider = new ethers.BrowserProvider(window.ethereum);
  const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

  try {
    const reputation = await contract.getUserReputation(address);
    return reputation;
  } catch (error: any) {
    throw new Error(error.message || 'Failed to get reputation');
  }
}
