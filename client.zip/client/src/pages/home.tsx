import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import CreatePost from "@/components/CreatePost";
import PostFeed from "@/components/PostFeed";
import { Link2 } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";

export default function Home() {
  const { isConnected } = useWallet();
  
  const { data: stats } = useQuery<{
    totalPosts: number;
    totalLikes: number;
    totalTips: string;
    totalUsers: number;
  }>({
    queryKey: ['/api/stats'],
    enabled: isConnected,
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Section */}
        {stats && (
          <section className="mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="stat-card glass-card rounded-xl p-6 border border-border/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Total Posts</p>
                    <p className="text-3xl font-bold text-foreground" data-testid="stats-total-posts">
                      {stats.totalPosts.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-file-alt text-primary text-xl"></i>
                  </div>
                </div>
              </div>
              
              <div className="stat-card glass-card rounded-xl p-6 border border-border/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Total Likes</p>
                    <p className="text-3xl font-bold text-foreground" data-testid="stats-total-likes">
                      {stats.totalLikes.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-heart text-accent text-xl"></i>
                  </div>
                </div>
              </div>
              
              <div className="stat-card glass-card rounded-xl p-6 border border-border/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Tips Sent</p>
                    <p className="text-3xl font-bold text-foreground" data-testid="stats-total-tips">
                      {parseFloat(stats.totalTips).toFixed(1)} <span className="text-lg">HELA</span>
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-gift text-primary text-xl"></i>
                  </div>
                </div>
              </div>
              
              <div className="stat-card glass-card rounded-xl p-6 border border-border/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Active Users</p>
                    <p className="text-3xl font-bold text-foreground" data-testid="stats-total-users">
                      {stats.totalUsers.toLocaleString()}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                    <i className="fas fa-users text-accent text-xl"></i>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Create Post */}
          <div className="lg:col-span-1">
            <CreatePost />
          </div>
          
          {/* Right Column - Feed */}
          <div className="lg:col-span-2">
            <PostFeed />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-border/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                  <Link2 className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-lg font-bold text-foreground">TrustTether</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Building trust through on-chain social interactions. Every like, comment, and tip is permanent and verifiable.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Documentation</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Smart Contract</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">IPFS Guide</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">HeLa Network</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Community</h4>
              <div className="flex items-center space-x-3">
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all">
                  <i className="fab fa-discord"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all">
                  <i className="fab fa-github"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all">
                  <i className="fab fa-telegram"></i>
                </a>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-border/30 flex flex-col md:flex-row items-center justify-between">
            <p className="text-sm text-muted-foreground">© 2024 TrustTether. Built on HeLa Network.</p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy</a>
              <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms</a>
              <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Security</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
