import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { User, Post } from "@shared/schema";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Edit, Heart, MessageCircle, Coins } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useWallet } from "@/hooks/useWallet";
import { useState } from "react";
import EditProfileModal from "@/components/EditProfileModal";

interface UserProfileData {
  user: User;
  posts: Post[];
}

export default function Profile() {
  const { address } = useParams<{ address: string }>();
  const { address: connectedAddress } = useWallet();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const { data, isLoading } = useQuery<UserProfileData>({
    queryKey: ["/api/users", address],
  });

  const isOwnProfile = connectedAddress?.toLowerCase() === address?.toLowerCase();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <Skeleton className="h-8 w-32 mb-8 bg-zinc-800" />
          <Card className="bg-zinc-900/50 border-zinc-800 backdrop-blur-sm mb-8">
            <CardHeader>
              <div className="flex items-center gap-4">
                <Skeleton className="h-20 w-20 rounded-full bg-zinc-800" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-6 w-48 bg-zinc-800" />
                  <Skeleton className="h-4 w-96 bg-zinc-800" />
                </div>
              </div>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <Card className="bg-zinc-900/50 border-zinc-800 p-8">
          <p className="text-zinc-400">User not found</p>
        </Card>
      </div>
    );
  }

  const { user, posts } = data;

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Link href="/" data-testid="link-back-home">
          <Button variant="ghost" className="mb-8 text-green-400 hover:text-green-300 hover:bg-zinc-900">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Feed
          </Button>
        </Link>

        <Card className="bg-zinc-900/50 border-zinc-800 backdrop-blur-sm mb-8">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20 border-2 border-green-500">
                  <AvatarImage src={user.avatarUrl || undefined} />
                  <AvatarFallback className="bg-zinc-800 text-2xl">
                    {user.name?.[0]?.toUpperCase() || user.address.slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-2xl font-bold text-white mb-1" data-testid="text-profile-name">
                    {user.name || `${user.address.slice(0, 6)}...${user.address.slice(-4)}`}
                  </h1>
                  <p className="text-sm text-zinc-400 font-mono mb-2" data-testid="text-profile-address">
                    {user.address}
                  </p>
                  <div className="flex gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Coins className="h-4 w-4 text-green-400" />
                      <span className="text-zinc-300" data-testid="text-profile-reputation">
                        {user.reputation} reputation
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="h-4 w-4 text-pink-400" />
                      <span className="text-zinc-300">{user.totalLikes} likes</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageCircle className="h-4 w-4 text-blue-400" />
                      <span className="text-zinc-300">{posts.length} posts</span>
                    </div>
                  </div>
                </div>
              </div>
              {isOwnProfile && (
                <Button
                  onClick={() => setIsEditModalOpen(true)}
                  variant="outline"
                  className="border-green-500 text-green-400 hover:bg-green-500/10"
                  data-testid="button-edit-profile"
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Profile
                </Button>
              )}
            </div>
          </CardHeader>
        </Card>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-white">Posts</h2>
          {posts.length === 0 ? (
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-8 text-center">
                <p className="text-zinc-400">No posts yet</p>
              </CardContent>
            </Card>
          ) : (
            posts.map((post) => (
              <Card key={post.id} className="bg-zinc-900/50 border-zinc-800 backdrop-blur-sm" data-testid={`card-post-${post.id}`}>
                <CardContent className="p-6">
                  <p className="text-white mb-4">{post.content}</p>
                  {post.imageHash && (
                    <img
                      src={`https://${post.imageHash}.ipfs.w3s.link`}
                      alt="Post"
                      className="rounded-lg max-h-96 w-full object-cover mb-4"
                    />
                  )}
                  <div className="flex items-center gap-4 text-sm text-zinc-400">
                    <div className="flex items-center gap-1">
                      <Heart className="h-4 w-4" />
                      <span>{post.likesCount}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MessageCircle className="h-4 w-4" />
                      <span>{post.commentsCount}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Coins className="h-4 w-4" />
                      <span>{post.tipsReceived} HELA</span>
                    </div>
                    <Badge variant="secondary" className="bg-zinc-800 text-zinc-300 ml-auto">
                      {formatDistanceToNow(new Date(post.createdAt!), { addSuffix: true })}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {isOwnProfile && (
        <EditProfileModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          currentUser={user}
        />
      )}
    </div>
  );
}
