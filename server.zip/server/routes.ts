import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema, insertLikeSchema, insertTipSchema, insertUserSchema, updateUserProfileSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all posts
  app.get("/api/posts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      const posts = await storage.getPosts(limit, offset);
      
      // Enrich posts with author info
      const enrichedPosts = await Promise.all(
        posts.map(async (post) => {
          const user = await storage.getUser(post.author);
          return {
            ...post,
            authorReputation: user?.reputation || 0,
            authorName: user?.name || null,
            authorAvatar: user?.avatarUrl || null
          };
        })
      );
      
      res.json(enrichedPosts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  // Create a new post
  app.post("/api/posts", async (req, res) => {
    try {
      const validated = insertPostSchema.parse(req.body);
      const post = await storage.createPost(validated);
      
      // Ensure user exists
      let user = await storage.getUser(validated.author);
      if (!user) {
        user = await storage.createUser({ address: validated.author });
      }
      
      res.status(201).json(post);
    } catch (error) {
      res.status(400).json({ message: "Invalid post data" });
    }
  });

  // Get comments for a post
  app.get("/api/posts/:postId/comments", async (req, res) => {
    try {
      const { postId } = req.params;
      const comments = await storage.getCommentsByPost(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Create a comment
  app.post("/api/comments", async (req, res) => {
    try {
      const validated = insertCommentSchema.parse(req.body);
      
      // Verify post exists
      const post = await storage.getPost(validated.postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Ensure commenter user exists
      let commenter = await storage.getUser(validated.author);
      if (!commenter) {
        commenter = await storage.createUser({ address: validated.author });
      }
      
      // Ensure post author user exists
      let author = await storage.getUser(post.author);
      if (!author) {
        author = await storage.createUser({ address: post.author });
      }
      
      const comment = await storage.createComment(validated);
      res.status(201).json(comment);
    } catch (error) {
      res.status(400).json({ message: "Invalid comment data" });
    }
  });

  // Create a like
  app.post("/api/likes", async (req, res) => {
    try {
      const validated = insertLikeSchema.parse(req.body);
      
      // Verify post exists
      const post = await storage.getPost(validated.postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check if user already liked this post
      const hasLiked = await storage.hasUserLikedPost(validated.postId, validated.author);
      if (hasLiked) {
        return res.status(409).json({ message: "Post already liked by this user" });
      }
      
      // Ensure liker user exists
      let liker = await storage.getUser(validated.author);
      if (!liker) {
        liker = await storage.createUser({ address: validated.author });
      }
      
      // Ensure post author user exists
      let author = await storage.getUser(post.author);
      if (!author) {
        author = await storage.createUser({ address: post.author });
      }
      
      const like = await storage.createLike(validated);
      res.status(201).json(like);
    } catch (error) {
      res.status(400).json({ message: "Invalid like data" });
    }
  });

  // Create a tip
  app.post("/api/tips", async (req, res) => {
    try {
      const validated = insertTipSchema.parse(req.body);
      
      // Verify post exists
      const post = await storage.getPost(validated.postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Ensure tipper user exists
      let tipper = await storage.getUser(validated.fromAddress);
      if (!tipper) {
        tipper = await storage.createUser({ address: validated.fromAddress });
      }
      
      // Ensure recipient user exists
      let recipient = await storage.getUser(validated.toAddress);
      if (!recipient) {
        recipient = await storage.createUser({ address: validated.toAddress });
      }
      
      const tip = await storage.createTip(validated);
      res.status(201).json(tip);
    } catch (error) {
      res.status(400).json({ message: "Invalid tip data" });
    }
  });

  // Get or create user with their posts
  app.get("/api/users/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const limit = parseInt(req.query.limit as string) || 20;
      
      let user = await storage.getUser(address);
      if (!user) {
        user = await storage.createUser({ address });
      }
      
      const posts = await storage.getUserPosts(address, limit);
      
      res.json({ user, posts });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user profile
  app.patch("/api/users/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const validated = updateUserProfileSchema.parse(req.body);
      
      const user = await storage.updateUserProfile(address, validated);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid profile data" });
    }
  });

  // Get platform stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getPlatformStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
