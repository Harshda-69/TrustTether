import { type Post, type Comment, type Like, type Tip, type User, type InsertPost, type InsertComment, type InsertLike, type InsertTip, type InsertUser, type UpdateUserProfile } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Posts
  getPost(id: string): Promise<Post | undefined>;
  getPosts(limit?: number, offset?: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePostEngagement(postId: string, likesCount?: number, commentsCount?: number, tipsReceived?: string): Promise<void>;

  // Comments
  getCommentsByPost(postId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;

  // Likes
  getLikesByPost(postId: string): Promise<Like[]>;
  createLike(like: InsertLike): Promise<Like>;
  hasUserLikedPost(postId: string, author: string): Promise<boolean>;

  // Tips
  getTipsByPost(postId: string): Promise<Tip[]>;
  createTip(tip: InsertTip): Promise<Tip>;

  // Users
  getUser(address: string): Promise<User | undefined>;
  getUserPosts(address: string, limit?: number): Promise<Post[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserReputation(address: string, reputation: number, totalLikes: number, totalTips: string): Promise<void>;
  updateUserProfile(address: string, profile: UpdateUserProfile): Promise<User | undefined>;

  // Platform stats
  getPlatformStats(): Promise<{
    totalPosts: number;
    totalLikes: number;
    totalTips: string;
    totalUsers: number;
  }>;
}

export class MemStorage implements IStorage {
  private posts: Map<string, Post>;
  private comments: Map<string, Comment>;
  private likes: Map<string, Like>;
  private tips: Map<string, Tip>;
  private users: Map<string, User>; // Keyed by lowercase address

  constructor() {
    this.posts = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.tips = new Map();
    this.users = new Map();
  }

  async getPost(id: string): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPosts(limit = 20, offset = 0): Promise<Post[]> {
    const allPosts = Array.from(this.posts.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    return allPosts.slice(offset, offset + limit);
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const post: Post = {
      ...insertPost,
      imageHash: insertPost.imageHash ?? null,
      id,
      createdAt: new Date(),
      likesCount: 0,
      commentsCount: 0,
      tipsReceived: "0"
    };
    this.posts.set(id, post);
    return post;
  }

  async updatePostEngagement(postId: string, likesCount?: number, commentsCount?: number, tipsReceived?: string): Promise<void> {
    const post = this.posts.get(postId);
    if (post) {
      if (likesCount !== undefined) post.likesCount = likesCount;
      if (commentsCount !== undefined) post.commentsCount = commentsCount;
      if (tipsReceived !== undefined) post.tipsReceived = tipsReceived;
      this.posts.set(postId, post);
    }
  }

  async getCommentsByPost(postId: string): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = randomUUID();
    const comment: Comment = {
      ...insertComment,
      id,
      createdAt: new Date()
    };
    this.comments.set(id, comment);
    
    // Update post comment count
    const post = this.posts.get(insertComment.postId);
    if (post) {
      post.commentsCount = (post.commentsCount || 0) + 1;
      this.posts.set(insertComment.postId, post);
    }
    
    return comment;
  }

  async getLikesByPost(postId: string): Promise<Like[]> {
    return Array.from(this.likes.values())
      .filter(like => like.postId === postId);
  }

  async createLike(insertLike: InsertLike): Promise<Like> {
    const id = randomUUID();
    const like: Like = {
      ...insertLike,
      id,
      createdAt: new Date()
    };
    this.likes.set(id, like);
    
    // Update post like count
    const post = this.posts.get(insertLike.postId);
    if (post) {
      post.likesCount = (post.likesCount || 0) + 1;
      this.posts.set(insertLike.postId, post);
      
      // Update author's reputation
      const author = await this.getUser(post.author);
      if (author) {
        const newTotalLikes = (author.totalLikes || 0) + 1;
        const totalTipsValue = parseFloat(author.totalTips || "0");
        const newReputation = newTotalLikes + Math.floor(totalTipsValue);
        await this.updateUserReputation(post.author, newReputation, newTotalLikes, author.totalTips || "0");
      }
    }
    
    return like;
  }

  async hasUserLikedPost(postId: string, author: string): Promise<boolean> {
    return Array.from(this.likes.values())
      .some(like => like.postId === postId && like.author === author);
  }

  async getTipsByPost(postId: string): Promise<Tip[]> {
    return Array.from(this.tips.values())
      .filter(tip => tip.postId === postId);
  }

  async createTip(insertTip: InsertTip): Promise<Tip> {
    const id = randomUUID();
    const tip: Tip = {
      ...insertTip,
      id,
      createdAt: new Date()
    };
    this.tips.set(id, tip);
    
    // Update post tips received
    const post = this.posts.get(insertTip.postId);
    if (post) {
      const currentTips = parseFloat(post.tipsReceived || "0");
      const newTip = parseFloat(insertTip.amount);
      post.tipsReceived = (currentTips + newTip).toString();
      this.posts.set(insertTip.postId, post);
      
      // Update recipient's reputation
      const recipient = await this.getUser(insertTip.toAddress);
      if (recipient) {
        const newTotalTips = parseFloat(recipient.totalTips || "0") + newTip;
        const newReputation = (recipient.totalLikes || 0) + Math.floor(newTotalTips);
        await this.updateUserReputation(insertTip.toAddress, newReputation, recipient.totalLikes || 0, newTotalTips.toString());
      }
    }
    
    return tip;
  }

  async getUser(address: string): Promise<User | undefined> {
    return this.users.get(address.toLowerCase());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const addressKey = insertUser.address.toLowerCase();
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      address: insertUser.address,
      id,
      name: insertUser.name ?? null,
      avatarUrl: insertUser.avatarUrl ?? null,
      reputation: 0,
      totalLikes: 0,
      totalTips: "0"
    };
    this.users.set(addressKey, user);
    return user;
  }

  async getUserPosts(address: string, limit = 20): Promise<Post[]> {
    const posts = Array.from(this.posts.values())
      .filter(post => post.author.toLowerCase() === address.toLowerCase())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);
    return posts;
  }

  async updateUserProfile(address: string, profile: UpdateUserProfile): Promise<User | undefined> {
    const addressKey = address.toLowerCase();
    const user = this.users.get(addressKey);
    if (!user) {
      return undefined;
    }
    
    if (profile.name !== undefined) {
      user.name = profile.name;
    }
    if (profile.avatarUrl !== undefined) {
      user.avatarUrl = profile.avatarUrl;
    }
    
    this.users.set(addressKey, user);
    return user;
  }

  async updateUserReputation(address: string, reputation: number, totalLikes: number, totalTips: string): Promise<void> {
    const addressKey = address.toLowerCase();
    const user = this.users.get(addressKey);
    if (user) {
      user.reputation = reputation;
      user.totalLikes = totalLikes;
      user.totalTips = totalTips;
      this.users.set(addressKey, user);
    }
  }

  async getPlatformStats(): Promise<{
    totalPosts: number;
    totalLikes: number;
    totalTips: string;
    totalUsers: number;
  }> {
    const totalPosts = this.posts.size;
    const totalLikes = this.likes.size;
    const totalUsers = this.users.size;
    
    let totalTipsSum = 0;
    const tipsArray = Array.from(this.tips.values());
    for (const tip of tipsArray) {
      totalTipsSum += parseFloat(tip.amount);
    }
    
    return {
      totalPosts,
      totalLikes,
      totalTips: totalTipsSum.toString(),
      totalUsers
    };
  }
}

export const storage = new MemStorage();
